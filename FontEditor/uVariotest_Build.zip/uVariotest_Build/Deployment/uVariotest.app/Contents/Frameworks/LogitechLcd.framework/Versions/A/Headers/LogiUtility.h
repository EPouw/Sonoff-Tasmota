//
//  LogiUtility.h
//  LogitechLCD
//
//  
//  Copyright (c) 2013 Logitech. All rights reserved.
//

#ifndef LogitechLCD_LogiUtility_h
#define LogitechLCD_LogiUtility_h


typedef unsigned char BYTE;
typedef UInt32          DWORD;
typedef void VOID;
typedef long unsigned int dword;
#endif
